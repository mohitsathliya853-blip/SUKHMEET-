# Sukhmeet — QR Surprise Website 💖

A responsive, single-page surprise website with a black-luxury theme, floating hearts, sparkles, and an animated envelope containing a personal note.

## Files
- `index.html` — the complete website (HTML, CSS, and JavaScript in one file).

## Preview locally
1. Download and unzip this project.
2. Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **public** repository, for example `sukhmeet-surprise`.
2. Upload `index.html` to the repository root and commit the change.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait a minute or two. GitHub will show your public website address, usually:
   `https://YOUR-USERNAME.github.io/sukhmeet-surprise/`

## Make the QR code
1. Copy the live GitHub Pages URL after the site has been published.
2. Open a QR-code generator such as https://www.qrcode-monkey.com/ or https://www.qr-code-generator.com/.
3. Paste the website URL, generate the QR code, and download it.
4. Scan it with a phone camera to test that it opens the website.

**Important:** A QR code can only point to a live public URL. Publish the site first, then create the QR code from that exact URL. Keep the repository public if you want to use free GitHub Pages.

## Personalize the note
Open `index.html` in any text editor and search for:
- `💖SUKHMEET …🤏🏻` to change the recipient name.
- `I ..!! 🤏🏻🤭✨🫳🏻` to change the sender name.
- The paragraphs inside `<article class="letter"...>` to edit the message.

The page uses Google Fonts from a CDN; the browser needs an internet connection to load those fonts. The animations and main page work without a build step.
